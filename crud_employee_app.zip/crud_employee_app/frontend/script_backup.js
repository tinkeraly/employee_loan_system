// Fetch and display employees
function loadEmployees() {
    fetch('../backend/getEmployees.php')
  .then(response => response.json())
  .then(data => {
    const tableBody = document.getElementById("employeeData");
    tableBody.innerHTML = '';

    data.forEach(emp => {
      const row = document.createElement('tr');
      row.innerHTML = `
        <td>${emp.EID}</td>
        <td>${emp.Name}</td>
        <td>${emp.DeptDescription}</td>
        <td>${emp.TotalLoan}</td>
      `;
      tableBody.appendChild(row);
    });
  })
  .catch(error => console.error('Error loading employee data:', error));

  }
  
  // Add new loan
  function submitLoan() {
    const employeeId = document.getElementById('employeeId').value;
    const loanAmount = document.getElementById('loanAmount').value;
  
    if (!employeeId || !loanAmount) {
      alert("Please enter both Employee ID and Loan Amount.");
      return;
    }
  
    fetch('../backend/addLoan.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ employee_id: employeeId, amount: loanAmount })
    })
      .then(response => response.json())
      .then(result => {
        alert(result.message);
        loadEmployees(); // Refresh employee list
      })
      .catch(error => console.error('Error submitting loan:', error));
  }
  
  // Load employees on page load
  window.onload = loadEmployees;
  